/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package prog5121.part1;
import java.util.Scanner;
/**
 *
 * @author lab_services_student
 */
public class PROG5121Part1 {
    private static String username;
    private static String password;
    private static String firstName;
    private static String lastName;
    private static int loginAttempts = 0;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);

        System.out.println("Welcome to the Registration and Login Feature"); 
        System.out.println("You will need to register before you continue");
        
        // Registration
        while (true) {
            System.out.print("Enter username (must be no more than 5 characters and must contain an underscore:");
            username = input.nextLine();

            if (checkUserName(username)) {
                System.out.println("Username successfully captured");
                break;
            } else {
                System.out.println("Username is not correctly formatted, please ensure that your username contains an underscore and is no more than 5 characters in length");
            }
        }

        while (true) {
            System.out.print("Enter password (must be at least 8 characters long, contain a capital letter, contain a number and contain a special character:");
            password = input.nextLine();

            if (checkPasswordComplexity(password)) {
                System.out.println("Password successfully captured");
                break;
            } else {
                System.out.println("Password is not correctly formatted, please ensure that the password contains at least 8 characters, a capital letter, a number and a special character");
            }
        }

        System.out.print("Enter first name: ");
        firstName = input.nextLine();

        System.out.print("Enter last name: ");
        lastName = input.nextLine();

        // User Login
        while (true) {
            if (loginAttempts >= 3) {
                System.out.println("Account has been locked, please contact administrator");
                System.exit(0);
            }

            System.out.print("Enter username: ");
            String inputUsername = input.nextLine();

            System.out.print("Enter password: ");
            String inputPassword = input.nextLine();

            if (loginUser(inputUsername, inputPassword)) {
                System.out.println("Welcome " + firstName + " " + lastName + ", it is great to see you again");
                break;
            } else {
                System.out.println("Username or password incorrect, please try again");
                loginAttempts++;
            }
        }
    }

    public static boolean checkUserName(String username) {
        return username.contains("_") && username.length() <= 5;
    }

    public static boolean checkPasswordComplexity(String password) {
        String regex = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,}$";
        return password.matches(regex);
    }

    public static String registerUser(String username, String password) {
        if (!checkUserName(username)) {
            return "The username is incorrectly formatted";
        } else if (!checkPasswordComplexity(password)) {
            return "The password does not meet the password requirements";
        } else {
            return "The two above conditions have been met and the user has been registered successfully";
        }
    }

    public static boolean loginUser(String inputUsername, String inputPassword) {
        return inputUsername.equals(username) && inputPassword.equals(password);
    }

    public static String returnLoginStatus(boolean success) {
        if (success) {
            return "Welcome " + firstName + " " + lastName + ", it is great to see you again";
        } else {
            return "Username or password incorrect, please try again";
        } 
    }
    
}
