/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

import javax.swing.JOptionPane;
/**
 *
 * @author lab_services_student
 */
public class TaskFeatureClass {
    public static void Arrays (){
        //Allows user to enter number of tasks
        int userCount = Integer.parseInt(JOptionPane.showInputDialog(null,"Please enter the desired number of tasks: "));
    
        //Arrays
        String [] taskName = new String[userCount];
        String [] devName = new String[userCount];
        String [] taskDescription = new String[userCount];
        String [] status = new String[userCount];
        String [] taskID =new String[userCount];
        String [] ID = new String[userCount];
        double [] taskDuration = new double[userCount];
        int [] numTask = new int[userCount];
        int [] taskStatus = new int[userCount];
        double totalHours = 0;
        
        //Select task status
        for (int i = 0; i <userCount; i++) {
                
        taskStatus [i] = Integer.parseInt( JOptionPane.showInputDialog(null, "Enter the status of your task :" + (i+1+ "\n")
               + "1) --> To do \n"
               + "2) --> Done \n"
               + "3) --> Doing"));
         
               if (taskStatus[i] == 3) {
                  status[i]= "To do";
                  
               } else if (taskStatus[i] == 2) {
                 status[i]= "Done";
               }
               else if (taskStatus[i] == 3){
                      status[i]= "Doing";
               } 
               
               taskName[i] = JOptionPane.showInputDialog(null,"Enter the name of the task: ");
               devName[i] = JOptionPane.showInputDialog(null,"Enter the name of the developer: ");
               taskDuration[i] = Double.parseDouble(JOptionPane.showInputDialog(null,"Enter the time the task takes: "));
               numTask[i] = i;                     
               taskDescription[i] = JOptionPane.showInputDialog(null,"Enter a description of said task \n"
               + "Note this has to be no more than 50 Characters");
               
                  if (taskDescription[i].length() <= 50) {
                    taskID[i] = taskName[i].substring(0, 2).toUpperCase();
                     ID[i] = devName[i].substring(devName[i].length()-3).toUpperCase();
                           
                  } else {
                      JOptionPane.showMessageDialog(null,"Please ensure your description does not surpass 50 characters");
                  }
 
               taskID[i] = taskName[i].substring(0, 2).toUpperCase();
               ID[i] = devName[i].substring(devName[i].length()-3).toUpperCase();
              
               totalHours+= taskDuration[i];            
        }
        
          //Displays data in the populated arrays
          for (int i = 0; i < userCount; i++) {
             displayMethod(i, taskName[i], numTask[i], devName[i], taskDuration[i], taskID[i], ID[i], status[i], taskDescription[i]);        
        }        
     } 
 
     public static void showReportNull ()
{
     JOptionPane.showMessageDialog(null, "Feature not implemented");
     
     int userChoice = Integer.parseInt(JOptionPane.showInputDialog(
              "1) Add tasks \n" 
            +"2) Quit"));
     
     if (userChoice == 1) {
         Arrays ();
        
    } else if(userChoice == 2){
        System.exit(2);
    }
                   
}
     //Display method
       public static void displayMethod(int userCount, String taskName, int numTask, String devName, double taskDuration, String firstTwo, String lastThree, String status,String taskDescription ) {
           JOptionPane.showMessageDialog(null, 
             "Task" + (userCount+1) + "\n"
           +"__________________________________\n"
           +"Task name: " + taskName + "\n"
           +"Task Number: " + numTask + "\n"
           +"Developer name: " + devName+ "\n"
           +"The description: " + taskDescription +"\n"
           +"Task duration: " + taskDuration +"\n"
           +"Task ID: " + firstTwo + ":" + numTask + ":" + lastThree+ "\n"
           +"Task Status: " + status + "\n"
           );
       }         
}
