/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author lab_services_student
 */
public class TaskFeatureClassTest {
    
    public TaskFeatureClassTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of Arrays method, of class TaskFeatureClass.
     */
    @Test
    public void testArrays() {
        System.out.println("Arrays");
        TaskFeatureClass.Arrays();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of showReportNull method, of class TaskFeatureClass.
     */
    @Test
    public void testShowReportNull() {
        System.out.println("showReportNull");
        TaskFeatureClass.showReportNull();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of displayMethod method, of class TaskFeatureClass.
     */
    @Test
    public void testDisplayMethod() {
        System.out.println("displayMethod");
        int userCount = 0;
        String taskName = "";
        int numTask = 0;
        String devName = "";
        double taskDuration = 0.0;
        String firstTwo = "";
        String lastThree = "";
        String status = "";
        String taskDescription = "";
        TaskFeatureClass.displayMethod(userCount, taskName, numTask, devName, taskDuration, firstTwo, lastThree, status, taskDescription);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
